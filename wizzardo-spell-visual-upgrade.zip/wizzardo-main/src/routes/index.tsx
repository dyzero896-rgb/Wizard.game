import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Arcane Realms — Wand Lab" },
      { name: "description", content: "Build spell wands and duel friends online in magical 3D arenas." },
      { property: "og:title", content: "Arcane Realms — Wand Lab" },
      { property: "og:description", content: "Build spell wands and duel friends online in magical 3D arenas." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Game,
});

function Game() {
  const src = "/game.html" + window.location.search;
  return (
    <iframe
      src={src}
      title="Arcane Realms"
      allow="fullscreen; pointer-lock; gamepad; autoplay"
      allowFullScreen
      className="fixed inset-0 h-full w-full border-0 bg-background"
    />
  );
}
