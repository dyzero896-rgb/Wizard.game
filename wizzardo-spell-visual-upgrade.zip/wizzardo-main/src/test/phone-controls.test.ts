import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const html = readFileSync("public/game.html", "utf8");

describe("Standalone game module wiring", () => {
  it("loads extracted pure helper modules without re-defining their implementations inline", () => {
    expect(html).toContain("import { phoneAimScore, phoneStick } from './game-modules/phone-controls.js';");
    expect(html).toContain("from './game-modules/network-validation.js';");
    expect(html).toContain("from './game-modules/room-rules.js';");
    expect(html).toContain("import { SPELLS as S } from './game-modules/spell-catalog.js';");
    expect(html).toContain("from './game-modules/wand-presets.js';");
    expect(html).toContain("from './game-modules/defense-catalog.js';");
    expect(html).not.toContain("function phoneStick(dx,dy,radius)");
  });
});
