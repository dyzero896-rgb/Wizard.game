// Shared room/mode rules. These helpers do not establish authorization; the future match server must.
export const VALID_GAME_MODES = Object.freeze([1, 2, 4, 6]);
export const VALID_MAP_IDS = Object.freeze(['sunken', 'ashen', 'moon', 'grove']);
export const MAX_ROOM_PLAYERS = 12;
const ROOM_CODE_RE = /^[A-Z0-9]{4}-?[A-Z0-9]{4}$/;

export function normalizeRoomCode(value) {
  const code = String(value ?? '').trim().toUpperCase();
  if (!ROOM_CODE_RE.test(code)) return '';
  return code.length === 8 ? `${code.slice(0, 4)}-${code.slice(4)}` : code;
}

export function isValidRoomCode(value) {
  return typeof value === 'string' && normalizeRoomCode(value) === value;
}

export function expectedPlayersForMode(mode) {
  return VALID_GAME_MODES.includes(mode) ? mode * 2 : 0;
}

export function isValidMapId(value) {
  return typeof value === 'string' && VALID_MAP_IDS.includes(value);
}
