// Pure rules used to harden the peer-to-peer online mode.
// Nothing here can make a modified client trustworthy; these checks narrow what a forged packet can do.
// See HARDENING.md for the threat model and what still needs a server.

export const WIRE_DAMAGE_SCALE = 1.6;      // outgoing packets carry projectile damage x 1.6
export const WAND_DAMAGE_MAX = 4.7;        // mortar power x affinity x crit
export const SHOP_DAMAGE_MAX = 1.5;        // shop damage upgrades are capped at +50%
export const MAX_PROJECTILE_DAMAGE = 60;
export const CAST_ORIGIN_MAX_DISTANCE = 9; // a cast must start near the sender's last known position
export const STATE_MAX_SPEED = 60;         // world units per second
export const STATE_SLACK = 4;
export const PREP_MAX_LEAD_MS = 35000;
export const ROUND_MS = 120000;
export const CAST_PACKET_DAMAGE_MAX = 35;
export const DAMAGE_BUDGET = Object.freeze({ capacity: 90, refillPerSecond: 45 });

const finite = (value) => typeof value === 'number' && Number.isFinite(value);

export function maxClaimedDamage(spell, mods) {
  const base = Math.max(1, finite(spell?.dmg) ? spell.dmg : 1);
  const dm = Math.min(3, Math.max(1, finite(mods?.dm) ? mods.dm : 1));
  return Math.min(MAX_PROJECTILE_DAMAGE, base * dm * WIRE_DAMAGE_SCALE * WAND_DAMAGE_MAX * SHOP_DAMAGE_MAX);
}

export function clampClaimedDamage(claimed, spell, mods) {
  if (!finite(claimed) || claimed <= 0) return 0;
  return Math.min(claimed, maxClaimedDamage(spell, mods));
}

// A single network cast batch cannot carry enough combined damage to eliminate
// a full-health player. Preserve relative spell damage while scaling the batch.
export function scaleCastPacketDamage(cast, spells, maxDamage = CAST_PACKET_DAMAGE_MAX) {
  if (!Array.isArray(cast?.l)) return [];
  const ceiling = finite(maxDamage) ? Math.max(0, maxDamage) : CAST_PACKET_DAMAGE_MAX;
  const amounts = cast.l.map((item) => clampClaimedDamage(item?.d, spells?.[item?.k], item?.m));
  const total = amounts.reduce((sum, amount) => sum + amount, 0);
  if (total <= ceiling || total <= 0) return amounts;
  const scale = ceiling / total;
  return amounts.map((amount) => amount * scale);
}

export function isNearSender(origin, sender, maxDistance = CAST_ORIGIN_MAX_DISTANCE) {
  if (!Array.isArray(origin) || origin.length !== 3 || !origin.every(finite) || !sender) return false;
  if (![sender.x, sender.y, sender.z].every(finite)) return false;
  return Math.hypot(origin[0] - sender.x, origin[1] - sender.y, origin[2] - sender.z) <= maxDistance;
}

// Limits how far an avatar can travel between two state packets. Teleports are allowed after a death/respawn.
export function limitStateStep(prev, next, elapsedMs) {
  const out = { ...next };
  if (!prev || !(prev.hp > 0) || next.dn !== prev.dn) return out;
  const seconds = Math.min(2, Math.max(0.05, (finite(elapsedMs) ? elapsedMs : 0) / 1000));
  const maxStep = STATE_MAX_SPEED * seconds + STATE_SLACK;
  const dx = next.x - prev.x, dy = next.y - prev.y, dz = next.z - prev.z;
  const dist = Math.hypot(dx, dy, dz);
  if (dist <= maxStep || dist === 0) return out;
  const k = maxStep / dist;
  out.x = prev.x + dx * k; out.y = prev.y + dy * k; out.z = prev.z + dz * k;
  return out;
}

// Token bucket per claimed sender id: returns how much of `amount` the sender is allowed to deal right now.
export function spendDamageBudget(buckets, id, amount, now, budget = DAMAGE_BUDGET) {
  if (!finite(amount) || amount <= 0) return 0;
  const bucket = buckets[id] || (buckets[id] = { tokens: budget.capacity, at: now });
  const elapsed = Math.max(0, now - bucket.at) / 1000;
  bucket.tokens = Math.min(budget.capacity, bucket.tokens + elapsed * budget.refillPerSecond);
  bucket.at = now;
  const granted = Math.min(amount, bucket.tokens);
  bucket.tokens -= granted;
  return granted;
}

// A presence "prep" deadline is only believed if it is in the near future.
export function sanitizePrepDeadline(value, now, maxLead = PREP_MAX_LEAD_MS) {
  if (!finite(value) || !Number.isSafeInteger(Math.floor(value))) return 0;
  if (value < now - 5000 || value > now + maxLead) return 0;
  return value;
}

// ---- rounds: last team standing -------------------------------------------------------------
export function teamsAlive(roster, eliminated, teamOf) {
  const alive = [0, 0];
  for (const player of roster || []) {
    const team = teamOf(player.id);
    if ((team === 0 || team === 1) && !eliminated.has(player.id)) alive[team] += 1;
  }
  return alive;
}

// over: a team has nobody left. winner: 0 | 1, or null when both teams are empty (draw).
export function roundOutcome(alive) {
  const [a, b] = alive;
  if (a > 0 && b > 0) return { over: false, winner: null };
  if (a === 0 && b === 0) return { over: true, winner: null };
  return { over: true, winner: a > 0 ? 0 : 1 };
}

// Used when the round timer runs out: more survivors wins, then more total health, otherwise a draw.
export function decideRoundWinner(alive, hp) {
  if (alive[0] !== alive[1]) return alive[0] > alive[1] ? 0 : 1;
  if (Math.round(hp[0]) !== Math.round(hp[1])) return hp[0] > hp[1] ? 0 : 1;
  return null;
}

// One side has completely left the room: the other side wins by forfeit.
export function forfeitWinner(roster, teamOf) {
  const present = [0, 0];
  for (const player of roster || []) {
    const team = teamOf(player.id);
    if (team === 0 || team === 1) present[team] += 1;
  }
  if (present[0] > 0 && present[1] === 0) return 0;
  if (present[1] > 0 && present[0] === 0) return 1;
  return null;
}

// ---- shop upgrades are per match: derive effective balance from defaults + the shop state ------
export function balanceForShop(defaults, shop) {
  const damage = Math.min(SHOP_DAMAGE_MAX, finite(shop?.damage) ? shop.damage : 1);
  const defense = Math.min(1.5, finite(shop?.defense) ? shop.defense : 1);
  const mana = Math.min(1.6, finite(shop?.mana) ? shop.mana : 1);
  return {
    spellDamage: Math.min(2, defaults.spellDamage + (damage - 1)),
    defenseDuration: Math.min(1.75, defaults.defenseDuration + (defense - 1)),
    manaMultiplier: 1 + 2 * (mana - 1),
  };
}
