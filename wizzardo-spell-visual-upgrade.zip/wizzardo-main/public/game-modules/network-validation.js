// Pure client-side packet validation. This rejects malformed data, but is not an anti-cheat boundary.
export const NET_LIMIT = Object.freeze({
  world: 100,
  health: 100,
  kills: 99999,
  castBatch: 16,
  castDamage: 60,
  maxProjectileId: 2147483647,
  maxStatusFrames: 600,
  castModifierMultiplier: 3,
  castModifierBounces: 6,
  rateWindow: 1000,
  maxEvents: 40,
});

export function netNumber(value, min, max) {
  return typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max;
}

export function netPlayerId(value) {
  return typeof value === 'string' && value.length >= 8 && value.length <= 80 && /^[a-zA-Z0-9_-]+$/.test(value) && !['__proto__', 'constructor', 'prototype'].includes(value);
}

export function isKnownPlayer(id, roster) {
  return netPlayerId(id) && Array.isArray(roster) && roster.some((player) => player && player.id === id);
}

export function isRateAllowed(bucket, id, event, limit = NET_LIMIT.maxEvents, now = Date.now(), windowMs = NET_LIMIT.rateWindow) {
  if (!bucket || typeof bucket !== 'object' || !netPlayerId(id) || typeof event !== 'string' || !event) return false;
  const key = `${id}:${event}`;
  const previous = bucket[key] || { at: now, n: 0 };
  if (now - previous.at >= windowMs || now < previous.at) {
    previous.at = now;
    previous.n = 0;
  }
  previous.n += 1;
  bucket[key] = previous;
  return previous.n <= limit;
}

export function isValidStatusFlags(status) {
  if (!status || typeof status !== 'object' || Array.isArray(status)) return false;
  const keys = Object.keys(status);
  if (keys.some((key) => !['b', 'p', 'f'].includes(key))) return false;
  return ['b', 'p', 'f'].every((key) => Number.isInteger(status[key]) && (status[key] === 0 || status[key] === 1));
}

export function isValidState(state, { roster = [], limits = NET_LIMIT } = {}) {
  return Boolean(
    state && isKnownPlayer(state.id, roster) &&
    netNumber(state.x, -limits.world, limits.world) &&
    netNumber(state.y, -5, 80) &&
    netNumber(state.z, -limits.world, limits.world) &&
    netNumber(state.ry, -Math.PI * 20, Math.PI * 20) &&
    netNumber(state.hp, 0, limits.health) &&
    netNumber(state.k, 0, limits.kills) &&
    netNumber(state.dn, 0, limits.kills) &&
    (!Object.hasOwn(state, 'st') || isValidStatusFlags(state.st))
  );
}


// Only these gameplay modifiers may cross the network. They are data, never instructions.
export const CAST_MODIFIER_LIMITS = Object.freeze({
  dm: Object.freeze([1, NET_LIMIT.castModifierMultiplier]),
  sm: Object.freeze([1, NET_LIMIT.castModifierMultiplier]),
  bl: Object.freeze([1, NET_LIMIT.castModifierMultiplier]),
  b: Object.freeze([0, NET_LIMIT.castModifierBounces]),
});

const CAST_MODIFIER_KEYS = Object.freeze(['dm', 'sm', 'bl', 'b', 'h', 'tr']);

export function isValidCastModifiers(modifiers) {
  if (!modifiers || typeof modifiers !== 'object' || Array.isArray(modifiers)) return false;
  const keys = Object.keys(modifiers);
  if (keys.some((key) => !CAST_MODIFIER_KEYS.includes(key))) return false;
  for (const key of ['dm', 'sm', 'bl']) {
    if (Object.hasOwn(modifiers, key) && !netNumber(modifiers[key], ...CAST_MODIFIER_LIMITS[key])) return false;
  }
  if (Object.hasOwn(modifiers, 'b') &&
      (!Number.isSafeInteger(modifiers.b) || modifiers.b < 0 || modifiers.b > NET_LIMIT.castModifierBounces)) return false;
  for (const key of ['h', 'tr']) {
    if (Object.hasOwn(modifiers, key) && modifiers[key] !== 1) return false;
  }
  return true;
}

export function copyCastModifiers(modifiers) {
  if (!isValidCastModifiers(modifiers)) return null;
  const safe = {};
  for (const key of CAST_MODIFIER_KEYS) {
    if (Object.hasOwn(modifiers, key)) safe[key] = modifiers[key];
  }
  return safe;
}

export function isValidCast(cast, { roster = [], spells = {}, limits = NET_LIMIT } = {}) {
  if (!cast || !isKnownPlayer(cast.id, roster) || !Array.isArray(cast.l) || cast.l.length < 1 || cast.l.length > limits.castBatch) return false;
  const seen = new Set();
  return cast.l.every((item) => {
    if (!item || !Number.isSafeInteger(item.i) || item.i < 1 || item.i > limits.maxProjectileId || seen.has(item.i)) return false;
    seen.add(item.i);
    return typeof item.k === 'string' && Object.hasOwn(spells, item.k) &&
      Array.isArray(item.p) && item.p.length === 3 && item.p.every((v) => netNumber(v, -limits.world, limits.world)) &&
      Array.isArray(item.v) && item.v.length === 3 && item.v.every((v) => netNumber(v, -25, 25)) &&
      netNumber(item.d, 0, limits.castDamage) && isValidCastModifiers(item.m);
  });
}
