// Pure lobby helpers shared by the UI and automated tests.
export const MAX_DISPLAY_NAME = 20;
const INVITE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

export function sanitizeDisplayName(value, fallback = 'Guest Mage') {
  const cleaned = String(value ?? '').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, MAX_DISPLAY_NAME);
  return cleaned || fallback;
}

export function formatInviteCode(bytes) {
  if (!bytes || typeof bytes.length !== 'number' || bytes.length < 8) return '';
  const chars = [];
  for (let i = 0; i < 8; i += 1) {
    const value = Number(bytes[i]);
    if (!Number.isInteger(value) || value < 0 || value > 255) return '';
    chars.push(INVITE_ALPHABET[value % INVITE_ALPHABET.length]);
  }
  const raw = chars.join('');
  return `${raw.slice(0, 4)}-${raw.slice(4)}`;
}
