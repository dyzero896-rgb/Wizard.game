// A device is treated as touch-capable if any browser signal indicates it.
// Some mobile browsers report fine/no pointer or omit the legacy ontouchstart property.
export function isTouchDevice({ coarsePointer = false, maxTouchPoints = 0, ontouchstart = false } = {}) {
  return coarsePointer === true || (Number.isFinite(maxTouchPoints) && maxTouchPoints > 0) || ontouchstart === true;
}

// Pure touch-control helpers shared with automated tests.
export function phoneStick(dx, dy, radius) {
  const length = Math.hypot(dx, dy);
  const scale = length > radius ? radius / length : 1;
  dx *= scale;
  dy *= scale;
  return {
    dx,
    dy,
    mx: Math.abs(dx / radius) < 0.12 ? 0 : dx / radius,
    my: Math.abs(dy / radius) < 0.12 ? 0 : -dy / radius,
  };
}

export function phoneAimScore(dot, distance, alive, friendly, visible) {
  return alive && !friendly && visible && distance > 1 && distance <= 45 && dot >= Math.cos(Math.PI / 18)
    ? dot - distance * 0.00025
    : -Infinity;
}
