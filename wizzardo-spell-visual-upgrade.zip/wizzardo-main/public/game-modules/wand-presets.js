// Named offensive wand presets, kept separate from cast resolution.
export const WAND_PRESETS = {
'Cluster bomb':['hit','bomb','tri','spark','spark','spark',0,0],
'Homing swarm':['hom','dmg','tri','spark','spark','spark',0,0],
'Chain reaction':['hit','fire','hit','bomb','dbl','frost','spark',0],
'Bouncing embers':['bnc','trl','tri','orb','orb','orb',0,0],
'Ice then boom':['tim','frost','big','bomb',0,0,0,0],
 'Storm cascade':['hom','lightning','tri','lightning','lightning',0,0,0],
 'Venom cloud':['tim','poison','big','poison',0,0,0,0],
 'Event Horizon':['hit','void','dmg','void',0,0,0,0],
 'Solar lance':['spd','sun','dbl','crystal','sun',0,0,0],
 'Tidal surge':['hom','water','tri','water',0,0,0,0],
 'Stonebreaker':['dmg','earth','earth','earth',0,0,0,0]};;
