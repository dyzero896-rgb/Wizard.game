// Pure match/team rules. These helpers make client-side transitions testable;
// they do not provide server authority or prove a remote player is trustworthy.
export function buildTeamAssignments(roster, mode) {
  if (!Array.isArray(roster) || ![1, 2, 4, 6].includes(mode)) return null;
  const assignments = Object.create(null);
  const counts = [0, 0];
  for (let index = 0; index < roster.length; index += 1) {
    const player = roster[index];
    if (!player || typeof player.id !== 'string' || !player.id) return null;
    let team;
    if (mode === 1) {
      // In a duel, preserve the first player's explicit choice and put the
      // second player on the opposing side. Auto-balance starts on Sun.
      if (index === 0) team = player.autoTeam === true || ![0, 1].includes(player.team) ? 0 : player.team;
      else {
        const opposing = assignments[roster[0].id] === 0 ? 1 : 0;
        team = index === 1 ? opposing : (counts[0] <= counts[1] ? 0 : 1);
      }
    } else if (player.autoTeam === true || ![0, 1].includes(player.team)) {
      team = counts[0] <= counts[1] ? 0 : 1;
    } else {
      team = player.team;
    }
    assignments[player.id] = team;
    counts[team] += 1;
  }
  return assignments;
}

export function isValidTeamAssignments(assignments, roster) {
  if (!assignments || typeof assignments !== 'object' || Array.isArray(assignments) || !Array.isArray(roster)) return false;
  const ids = roster.map((player) => player?.id);
  const keys = Object.keys(assignments);
  return keys.length === ids.length && ids.every((id) => typeof id === 'string' && Object.hasOwn(assignments, id) && [0, 1].includes(assignments[id])) &&
    keys.every((id) => ids.includes(id) && [0, 1].includes(assignments[id]));
}

export function hasBothTeams(assignments, roster) {
  return isValidTeamAssignments(assignments, roster) &&
    roster.some((player) => assignments[player.id] === 0) &&
    roster.some((player) => assignments[player.id] === 1);
}

export function calculateTeamScore(currentScore, scoringTeam, winningScore = 3) {
  if (!Array.isArray(currentScore) || currentScore.length !== 2 || !currentScore.every((value) => Number.isInteger(value) && value >= 0) ||
      ![0, 1].includes(scoringTeam) || !Number.isInteger(winningScore) || winningScore < 1) return null;
  const score = currentScore.slice();
  score[scoringTeam] += 1;
  return { score, finished: score[scoringTeam] >= winningScore, scoringTeam };
}
