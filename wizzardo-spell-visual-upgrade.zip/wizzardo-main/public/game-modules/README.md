# Game modules

`game.html` is the runtime entry point. These modules intentionally contain pure rules/data with no DOM or Three.js dependency so they can be tested without launching the renderer.

- `spell-catalog.js`: original offensive spell data, kept value-for-value as an imported object. Effects and cast sequencing remain in `game.html`.
- `spell-visual-catalog.js`: visual identities for all 13 projectile spells (silhouette, palette, trail, impact); contains no gameplay tuning and is consumed by the renderer in `game.html`.
- `defense-catalog.js`: original defensive spell definitions.
- `wand-presets.js`: named offensive wand configurations.
- `phone-controls.js`: pure analog-stick normalization and aim-assist score function.
- `network-validation.js`: packet validation and rate limiting primitives. Runtime adapters in `game.html` connect these helpers to the current roster and spell catalog.
- `room-rules.js`: invite-code format/normalization, supported match modes, max room sizing and map allowlist.

Future extractions should move one subsystem at a time and retain small adapters at the game entry point until tests cover the subsystem's state transitions. Do not move Three.js effect/rendering functions before adding browser-level regression coverage. The current room/game remains client-hosted; these validations do not provide authoritative anti-cheat.
- `defense-sync.js`: bounded validation for replicated defensive spell casts, remaining-life updates and end events. `game.html` renders one of ten corresponding defense geometries for remote avatars; geometric visual replicas are not an authoritative collision simulation.

- `network-validation.js`: cast packets now require an explicit `m` object containing only bounded `dm`, `sm`, `bl`, `b`, `h`, and `tr` modifier data. Unknown keys, invalid types, and out-of-range values are rejected. `copyCastModifiers()` creates the allowlisted payload from the local spell evaluator. This remains client-side validation, not server authority.
- `homing.js`: pure homing target selection and velocity steering. It filters the caster, dead/invisible players, teammates in team modes, malformed positions and targets beyond the bounded range. The live game chooses targets from locally replicated avatar positions; cast packets do not carry target IDs or arbitrary steering behavior.

- `combat-network.js`: validates small hit-confirmation messages containing known player IDs, a locally issued projectile sequence, bounded damage, a known spell key and a bounded impact position. The attacker accepts hits only for its own unexpired projectile IDs and once per target. This remains presentation-level client validation, not server-authoritative combat.
- Multiplayer state packets now include a strict three-flag status object (`b`, `p`, `f`). Remote avatars render burn, poison and freeze visuals from those validated flags. Cast projectile IDs allow hit confirmations to refer to one specific shot without sending behavior or target-selection instructions.

- `status-combat.js`: deterministic burn/poison tick intervals, per-status source attribution, and positive-to-zero lethal transition detection. The runtime sends these ticks through `hurtPlayer()` so existing death, respawn, attacker-credit, and team-round handling remains shared with direct spell damage.

- `match-rules.js`: deterministic 1v1 opposition, auto-balanced team assignments, team-map validation and bounded team-score transitions. These are local rules only; host election and score messages remain client-hosted.
