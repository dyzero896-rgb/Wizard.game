// Pure homing helpers. Target selection is local to each client; no target ID
// or arbitrary steering instruction is accepted from a cast packet.

function finiteVector3(value) {
  return Array.isArray(value) && value.length === 3 && value.every(Number.isFinite);
}

export function selectHomingTarget(origin, candidates, {
  ownerId = null,
  ownerTeam = null,
  teamsEnabled = false,
  maxDistance = 130,
  preferredId = null,
} = {}) {
  if (!finiteVector3(origin) || !Array.isArray(candidates) ||
      !Number.isFinite(maxDistance) || maxDistance <= 0) return null;

  const maxDistanceSq = maxDistance * maxDistance;
  let best = null;
  let bestDistanceSq = Infinity;
  let preferred = null;

  for (const candidate of candidates) {
    if (!candidate || typeof candidate.id !== 'string' || !candidate.id || candidate.id === ownerId) continue;
    if (candidate.alive !== true || candidate.visible === false || !finiteVector3(candidate.position)) continue;
    if (teamsEnabled && ownerTeam !== null && candidate.team === ownerTeam) continue;

    const dx = candidate.position[0] - origin[0];
    const dy = candidate.position[1] - origin[1];
    const dz = candidate.position[2] - origin[2];
    const distanceSq = dx * dx + dy * dy + dz * dz;
    if (distanceSq > maxDistanceSq) continue;

    if (candidate.id === preferredId) {
      preferred = candidate;
      break;
    }
    if (distanceSq < bestDistanceSq ||
        (distanceSq === bestDistanceSq && candidate.id < (best?.id || '\uffff'))) {
      best = candidate;
      bestDistanceSq = distanceSq;
    }
  }

  const target = preferred || best;
  return target ? { id: target.id, position: target.position.slice() } : null;
}

export function steerHomingVelocity(velocity, origin, target, turnRate = 0.12) {
  if (!finiteVector3(velocity) || !finiteVector3(origin) || !finiteVector3(target) ||
      !Number.isFinite(turnRate)) return finiteVector3(velocity) ? velocity.slice() : [0, 0, 0];

  const speed = Math.hypot(...velocity);
  if (speed < 1e-9) return velocity.slice();
  const dx = target[0] - origin[0];
  const dy = target[1] - origin[1];
  const dz = target[2] - origin[2];
  const distance = Math.hypot(dx, dy, dz);
  if (distance < 1e-9) return velocity.slice();

  const rate = Math.max(0, Math.min(1, turnRate));
  const current = velocity.map((component) => component / speed);
  const desired = [dx / distance, dy / distance, dz / distance];
  const mixed = current.map((component, index) => component * (1 - rate) + desired[index] * rate);
  const mixedLength = Math.hypot(...mixed);
  if (mixedLength < 1e-9) return desired.map((component) => component * speed);
  return mixed.map((component) => component / mixedLength * speed);
}
