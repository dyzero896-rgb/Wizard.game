// Defensive spell catalog data only; the defense runtime remains in game.html.
export const DEFENSE_SPELLS = {
 flame:{n:'Flame Ward',el:'Fire',c:26,col:'#ff8a3d',cd:110,life:300,d:'A ring of living fire circles you. It burns anything that touches it, ignites incoming bolts and cuts blast knockback.'},
 glacier:{n:'Glacial Shell',el:'Ice',c:28,col:'#8fe3ff',cd:130,life:360,d:'Faceted ice grows around you. It chills enemies nearby, absorbs three hits, then shatters in a freezing burst.'},
 storm:{n:'Storm Aegis',el:'Lightning',c:30,col:'#a8f7ff',cd:120,life:300,d:'A crackling dome of electricity. It strikes close enemies with arcs and discharges against incoming bolts.'},
 venom:{n:'Venom Veil',el:'Poison',c:24,col:'#8dff73',cd:100,life:420,d:'A toxic mist wraps around you and poisons everything that enters it.'},
 bulwark:{n:'Stone Bulwark',el:'Earth',c:30,col:'#b88a58',cd:140,life:420,d:'Raises a solid stone wall in front of you that blocks bolts and movement, shoving enemies back as it rises.'},
 gale:{n:'Gale Barrier',el:'Wind',c:22,col:'#b6fff0',cd:90,life:300,d:'A spinning wall of wind pushes enemies away and bends incoming bolts off course.'},
 tide:{n:'Tidal Bubble',el:'Water',c:26,col:'#4ebdff',cd:110,life:330,d:'A glossy water sphere that absorbs four hits, soaks and shoves back enemies, then bursts.'},
 voidstep:{n:'Voidstep',el:'Void',c:24,col:'#8b5cf6',cd:80,life:150,d:'Slip half out of reality: you move faster, take little knockback and swallow bolts that reach you.'},
 radiant:{n:'Radiant Shield',el:'Light',c:28,col:'#fff0a1',cd:120,life:300,d:'A golden energy barrier follows your aim and burns away bolts. Casting it dazzles nearby enemies.'},
 mirror:{n:'Prism Mirror',el:'Crystal',c:30,col:'#d5b8ff',cd:130,life:300,d:'Floating crystal panes reflect incoming bolts back at their source with extra force.'}};;
