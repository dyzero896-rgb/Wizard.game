// Visual identity only. Do not put gameplay values (damage, speed, radius, cost, lifetime) here.
export const SPELL_VISUALS = Object.freeze({
  spark: Object.freeze({ primary: '#ffe36e', accent: '#fff8cf', silhouette: 'forked-bolt', trail: 'gold-static', impact: 'starburst' }),
  fire: Object.freeze({ primary: '#ff6426', accent: '#ffe37a', silhouette: 'flame-core', trail: 'ember-comet', impact: 'flame-burst' }),
  bomb: Object.freeze({ primary: '#292832', accent: '#ffad43', silhouette: 'iron-fuse-orb', trail: 'soot-fuse', impact: 'shrapnel-cloud' }),
  frost: Object.freeze({ primary: '#8feaff', accent: '#effcff', silhouette: 'ice-cluster', trail: 'frost-mist', impact: 'ice-shatter' }),
  orb: Object.freeze({ primary: '#a66bff', accent: '#f0c6ff', silhouette: 'arcane-orbital', trail: 'violet-orbits', impact: 'arcane-ripple' }),
  lightning: Object.freeze({ primary: '#47eaff', accent: '#efffff', silhouette: 'storm-lance', trail: 'electric-arcs', impact: 'thunder-flash' }),
  poison: Object.freeze({ primary: '#78ed3e', accent: '#d4ff67', silhouette: 'toxic-glob', trail: 'venom-bubbles', impact: 'toxic-cloud' }),
  void: Object.freeze({ primary: '#170d2a', accent: '#c17aff', silhouette: 'dark-singularity', trail: 'inward-spiral', impact: 'void-collapse' }),
  gale: Object.freeze({ primary: '#55eacb', accent: '#d9fff5', silhouette: 'wind-disc', trail: 'wind-ribbons', impact: 'air-shear' }),
  sun: Object.freeze({ primary: '#ffb52e', accent: '#fff5a8', silhouette: 'solar-corona', trail: 'solar-flare', impact: 'radiant-flash' }),
  crystal: Object.freeze({ primary: '#b77bff', accent: '#fff0ff', silhouette: 'prism-spear', trail: 'prism-glints', impact: 'crystal-splinters' }),
  water: Object.freeze({ primary: '#168fe0', accent: '#b9f3ff', silhouette: 'tidal-drop', trail: 'water-droplets', impact: 'tidal-splash' }),
  earth: Object.freeze({ primary: '#9f754d', accent: '#ddbd91', silhouette: 'fractured-rock', trail: 'stone-dust', impact: 'rock-fragments' }),
});

export const PROJECTILE_VISUAL_KEYS = Object.freeze(Object.keys(SPELL_VISUALS));

export function hasCompleteProjectileVisuals(spells) {
  const projectileKeys = Object.keys(spells || {}).filter((key) => spells[key]?.t === 'p');
  return projectileKeys.length === PROJECTILE_VISUAL_KEYS.length
    && projectileKeys.every((key) => Object.hasOwn(SPELL_VISUALS, key));
}
