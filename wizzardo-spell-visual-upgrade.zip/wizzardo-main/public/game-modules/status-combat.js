// Pure damage-over-time rules. Runtime adapters apply these ticks through hurtPlayer(),
// so lethal burn/poison uses the same death and kill-credit path as direct spell damage.
export const STATUS_DOT_RULES = Object.freeze({
  burn: Object.freeze({ intervalFrames: 30, damage: 1.5 }),
  poison: Object.freeze({ intervalFrames: 30, damage: 1 }),
});

export function statusTickDamage(status, remainingFrames) {
  const rule = STATUS_DOT_RULES[status];
  if (!rule || !Number.isSafeInteger(remainingFrames) || remainingFrames <= 0) return 0;
  return remainingFrames % rule.intervalFrames === 0 ? rule.damage : 0;
}

export function statusSource(status, sources = {}) {
  if (!Object.hasOwn(STATUS_DOT_RULES, status) || !sources || typeof sources !== 'object' || Array.isArray(sources)) return null;
  const source = sources[status];
  return typeof source === 'string' && source.length >= 8 && source.length <= 80 ? source : null;
}

export function isLethalTransition(previousHealth, nextHealth) {
  return Number.isFinite(previousHealth) && Number.isFinite(nextHealth) && previousHealth > 0 && nextHealth <= 0;
}
