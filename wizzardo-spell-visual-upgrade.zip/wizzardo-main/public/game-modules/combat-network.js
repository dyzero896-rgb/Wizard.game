// Minimal, bounded hit-confirmation messages. These checks protect the client UI
// from malformed messages; they do not make client-hosted combat authoritative.
import { isKnownPlayer, netNumber } from './network-validation.js';

export const COMBAT_HIT_LIMITS = Object.freeze({
  damage: 60,
  world: 100,
  projectileId: 2147483647,
});

const HIT_KEYS = Object.freeze(['from', 'to', 'i', 'd', 'k', 'p']);

export function isValidCombatHit(hit, { roster = [], spells = {}, limits = COMBAT_HIT_LIMITS } = {}) {
  if (!hit || typeof hit !== 'object' || Array.isArray(hit)) return false;
  if (Object.keys(hit).some((key) => !HIT_KEYS.includes(key))) return false;
  return isKnownPlayer(hit.from, roster) && isKnownPlayer(hit.to, roster) && hit.from !== hit.to &&
    Number.isSafeInteger(hit.i) && hit.i >= 1 && hit.i <= limits.projectileId &&
    netNumber(hit.d, 0.1, limits.damage) && typeof hit.k === 'string' && Object.hasOwn(spells, hit.k) &&
    Array.isArray(hit.p) && hit.p.length === 3 && hit.p.every((value) => netNumber(value, -limits.world, limits.world));
}
