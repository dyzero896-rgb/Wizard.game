// Pure validation for replicated defensive spell state. Geometry and collision stay in game.html.
export const DEFENSE_SYNC_LIMITS = Object.freeze({ maxLifeFrames: 1000, maxSequence: 2_147_483_647, maxYaw: Math.PI * 32 });

function knownSender(packet, roster) {
  return Boolean(packet && typeof packet.id === 'string' && Array.isArray(roster) && roster.some((player) => player && player.id === packet.id));
}

function validSequence(value) {
  return Number.isSafeInteger(value) && value >= 1 && value <= DEFENSE_SYNC_LIMITS.maxSequence;
}

export function isValidDefenseCast(packet, { roster = [], defenses = {}, limits = DEFENSE_SYNC_LIMITS } = {}) {
  return Boolean(
    knownSender(packet, roster) && typeof packet.key === 'string' && Object.hasOwn(defenses, packet.key) &&
    validSequence(packet.seq) && typeof packet.yaw === 'number' && Number.isFinite(packet.yaw) &&
    packet.yaw >= -limits.maxYaw && packet.yaw <= limits.maxYaw &&
    Number.isSafeInteger(packet.life) && packet.life >= 1 && packet.life <= limits.maxLifeFrames
  );
}

export function isValidDefenseState(packet, { roster = [], limits = DEFENSE_SYNC_LIMITS } = {}) {
  return Boolean(
    knownSender(packet, roster) && validSequence(packet.seq) &&
    Number.isSafeInteger(packet.life) && packet.life >= 0 && packet.life <= limits.maxLifeFrames
  );
}

export function isValidDefenseEnd(packet, { roster = [] } = {}) {
  return Boolean(knownSender(packet, roster) && validSequence(packet.seq));
}
