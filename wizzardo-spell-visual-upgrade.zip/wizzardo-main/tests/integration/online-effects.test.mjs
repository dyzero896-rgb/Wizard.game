import test, { after, before } from 'node:test';
import assert from 'node:assert/strict';
import { loadGame } from './harness.mjs';

let g, ME, OPP;
before(async () => { g = await loadGame(); await g.ev("netJoin('AB12-CD34')"); g.ev('NET.joinT=100'); ME = g.ev('NET.id'); OPP = 'opponent-0001'; });
after(() => g.dispose());
const duel = () => {
  g.ev('foes.forEach(rmFoe);foes=[];train=false;NET.inArena=true;NET.prepUntil=0;P.hp=P.maxHp;P.x=0;P.z=6;P.y=0;P.yaw=0;P.pit=0;P.downT=0;P.burn=P.poison=P.slow=0;window.__sent.length=0;Object.keys(NET_RX).forEach(k=>delete NET_RX[k]);Object.keys(NET_BUDGET).forEach(k=>delete NET_BUDGET[k])');
  g.presence([[ME, { name: 'Me', t: 100, mode: 1 }], [OPP, { name: 'Rival', t: 200, mode: 1 }]]);
};

test('my own homing shot turns toward the rival in a 1v1', () => {
  duel();
  g.message('state', { id: OPP, x: 9, y: 0, z: -10, ry: 0, hp: 100, k: 0, dn: 0, st: { b: 0, p: 0, f: 0 } });
  for (let i = 0; i < 20; i++) g.ev('upd()');
  g.ev("wands[cur]=makeWand('storm',['hom','spark']);wands[cur].m=9999;wands[cur].d=0;fire()");
  const before = g.ev('(()=>{const p=pr[pr.length-1];return p?[p.v.x,p.v.z]:null})()');
  for (let i = 0; i < 25; i++) g.ev('upd()');
  const after = g.ev('(()=>{const p=pr[pr.length-1];return p?[p.v.x,p.v.z]:null})()');
  assert.ok(before && after, 'the projectile is still in flight');
  const turned = Math.abs(after[0] - before[0]) > 0.02 || Math.abs(after[1] - before[1]) > 0.02;
  assert.ok(turned, `homing did not steer the shot (vx ${before[0].toFixed(3)} -> ${after[0].toFixed(3)})`);
});

test("the rival's homing shot steers toward me", () => {
  duel();
  g.message('state', { id: OPP, x: 0, y: 0, z: -12, ry: 0, hp: 100, k: 0, dn: 0, st: { b: 0, p: 0, f: 0 } });
  // aimed 6 units to my left, so only steering can make it hit me
  g.message('cast', { id: OPP, l: [{ i: 1, k: 'spark', p: [-6, 1.2, -12], v: [0, 0, 0.3], d: 5, m: { h: 1 } }] });
  const lateral0 = g.ev('(()=>{const f=foes[foes.length-1];return f?f.pos.x:null})()');
  const x0 = g.ev('(()=>{const f=foes[foes.length-1];return f?f.v.x:null})()');
  for (let i = 0; i < 20; i++) g.ev('upd()');
  const x1 = g.ev('(()=>{const f=foes[foes.length-1];return f?f.v.x:null})()');
  assert.notEqual(lateral0, null, 'the incoming shot exists');
  if (x1 !== null) assert.ok(x1 > x0 + 0.01, `incoming homing shot did not bend toward me (vx ${x0} -> ${x1})`);
});

test('a burn that I receive from the rival is applied and shown on my side', () => {
  duel();
  g.message('state', { id: OPP, x: 0, y: 0, z: -3, ry: 0, hp: 100, k: 0, dn: 0, st: { b: 0, p: 0, f: 0 } });
  g.message('cast', { id: OPP, l: [{ i: 1, k: 'fire', p: [0, 1.2, -1.8], v: [0, 0, 0.25], d: 9, m: {} }] });
  for (let i = 0; i < 60; i++) g.ev('upd()');
  assert.ok(g.ev('P.burn') > 0, 'burning is applied to me');
});

test('a freeze I receive is applied', () => {
  duel();
  g.message('state', { id: OPP, x: 0, y: 0, z: -3, ry: 0, hp: 100, k: 0, dn: 0, st: { b: 0, p: 0, f: 0 } });
  g.message('cast', { id: OPP, l: [{ i: 1, k: 'frost', p: [0, 1.2, -1.8], v: [0, 0, 0.25], d: 5, m: {} }] });
  for (let i = 0; i < 60; i++) g.ev('upd()');
  assert.ok(g.ev('P.slow') > 0, 'freeze is applied to me');
});

test('the rival\'s status flags are carried in its state packet and shown on its avatar', () => {
  duel();
  g.message('state', { id: OPP, x: 0, y: 0, z: -10, ry: 0, hp: 100, k: 0, dn: 0, st: { b: 1, p: 0, f: 1 } });
  const st = g.ev(`JSON.stringify(NET.st.get('${OPP}').st)`);
  assert.equal(JSON.parse(st).b, 1, 'burn flag received');
  g.ev('for(let i=0;i<4;i++)upd()');
  assert.equal(g.ev(`NET.av.get('${OPP}')?.g?.visible`), true, 'rival avatar is visible');
});
