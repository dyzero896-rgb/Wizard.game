import test, { after, before } from 'node:test';
import assert from 'node:assert/strict';
import { loadGame } from './harness.mjs';

let game;
before(async () => { game = await loadGame(); });
after(() => game.dispose());

test('the game boots with spells, wands, defences and arenas', () => {
  assert.ok(game.ev('Object.keys(S).length') >= 20);
  assert.ok(game.ev('Object.keys(CAT).length') >= 10);
  assert.equal(game.ev('Object.keys(DS).length'), 10);
  assert.deepEqual(game.ev('Object.keys(ARENAS)').sort(), ['ashen', 'grove', 'moon', 'sunken']);
  assert.equal(game.ev('(()=>{for(let i=0;i<60;i++)upd();return 1})()'), 1);
});

test('every defence spell can be cast and expires cleanly', () => {
  const failures = game.ev(`(()=>{const bad=[];Object.keys(DS).forEach(k=>{try{DW.slots[0]=k;DW.ptr=0;DW.cd=0;DW.m=DW.mana;castDefense();for(let i=0;i<DS[k].life+20;i++)upd()}catch(e){bad.push(k+': '+e.message)}});return bad})()`);
  assert.deepEqual(failures, []);
  assert.equal(game.ev('DEFX.length'), 0, 'no defence effect is left running');
});

test('every projectile spell fires and flies without errors', () => {
  const failures = game.ev(`(()=>{const bad=[];Object.keys(S).filter(k=>S[k].t=='p').forEach(k=>{try{wands[cur]=makeWand('archmage',[k]);wands[cur].m=9999;wands[cur].d=0;fire();for(let i=0;i<60;i++)upd()}catch(e){bad.push(k+': '+e.message)}});return bad})()`);
  assert.deepEqual(failures, []);
});

test('every arena builds and runs', () => {
  const failures = game.ev(`(()=>{const bad=[];Object.keys(ARENAS).forEach(id=>{try{buildArena(id);for(let i=0;i<30;i++)upd()}catch(e){bad.push(id+': '+e.message)}});return bad})()`);
  assert.deepEqual(failures, []);
});

test('a 3000 frame soak with constant casting stays bounded and never produces NaN', () => {
  const result = game.ev(`(()=>{train=true;P.hp=P.maxHp;wands[cur]=makeWand('archmage',['fire','frost','spark','bomb','orb','dmg']);const keys=Object.keys(DS);let maxChildren=0;
   for(let f=0;f<3000;f++){if(f%25==0){wands[cur].m=9999;wands[cur].d=0;fire()}if(f%140==0){DW.slots[0]=keys[(f/140|0)%keys.length];DW.ptr=0;DW.cd=0;DW.m=DW.mana;castDefense()}P.hp=Math.max(P.hp,40);upd();maxChildren=Math.max(maxChildren,sc.children.length)}
   return {maxChildren,projectiles:pr.length,nan:[P.x,P.y,P.z,P.hp].some(v=>v!==v)}})()`);
  assert.equal(result.nan, false);
  assert.ok(result.maxChildren < 600, `scene grew to ${result.maxChildren} objects`);
  assert.ok(result.projectiles < 40);
});
