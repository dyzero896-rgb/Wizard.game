import test, { after, before } from 'node:test';
import assert from 'node:assert/strict';
import { loadGame } from './harness.mjs';

let g;
let me;
const opponent = 'opponent-0001';
before(async () => {
  g = await loadGame({ touch: true });
  await g.ev("netJoin('AB12-CD34')");
  me = g.ev('NET.id');
});
after(() => g.dispose());

test('a touch device is placed in editor mode initially and receives the return button', () => {
  assert.equal(g.window.document.body.classList.contains('touchedit'), true);
  assert.ok(g.window.document.getElementById('resumeTouch'));
});

test('an online round enters touch play, and editing exposes Return to arena', () => {
  g.presence([[me, { name: 'Phone', t: 100, mode: 1 }], [opponent, { name: 'Laptop', t: 200, mode: 1 }]]);
  g.ev(`applyMatchState({host:'${me}',phase:'round',round:1,score:[0,0],teams:{'${me}':0,'${opponent}':1},map:'sunken',mode:1})`);
  assert.equal(g.window.document.body.classList.contains('touchplay'), true);
  assert.equal(g.window.document.body.classList.contains('touchedit'), false);
  g.ev('stopTouch()');
  assert.equal(g.window.document.body.classList.contains('touchedit'), true);
  assert.equal(g.window.document.body.classList.contains('touchplay'), false);
});
