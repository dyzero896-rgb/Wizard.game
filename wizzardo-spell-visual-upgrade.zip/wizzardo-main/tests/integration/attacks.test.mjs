import test, { after, before } from 'node:test';
import assert from 'node:assert/strict';
import { loadGame } from './harness.mjs';

let ME = 'me-0000'; const OPP = 'opponent-0001', ALLY = 'teammate-0002', OPP2 = 'opponent-0003', EVIL = 'cheater-00099';
let g;
before(async () => { g = await loadGame(); await g.ev("netJoin('AB12-CD34')"); g.ev('NET.joinT=100'); ME = g.ev('NET.id'); });
after(() => g.dispose());
const reset = () => g.ev(`(()=>{foes.forEach(rmFoe);foes=[];train=false;NET.inArena=true;NET.prepUntil=0;P.hp=P.maxHp;P.x=0;P.z=6;P.y=0;P.yaw=0;P.pit=0;P.downT=0;P.burn=P.poison=P.slow=0;window.__sent.length=0;Object.keys(NET_RX).forEach(k=>delete NET_RX[k]);Object.keys(NET_BUDGET).forEach(k=>delete NET_BUDGET[k]);return 1})()`);
// Join times increase with list order, so the first listed player is the host (earliest join).
const roster = (list) => g.presence(list.map(([id, m], i) => [id, { name: id, t: 100 + i, mode: 1, ...m }]));
const state = (id, x, y, z, hp = 100, dn = 0) => g.message('state', { id, x, y, z, ry: 0, hp, k: 0, dn, st: { b: 0, p: 0, f: 0 } });
const teams = (ids) => ids; // reserved for readability in the tests below

test('a forged cast cannot hurt you: shells must start near a sender whose position we know', () => {
  reset(); roster([[ME, {}], [OPP, {}]]); state(OPP, 30, 0, -30);
  g.message('cast', { id: OPP, l: Array.from({ length: 16 }, (_, i) => ({ i: i + 1, k: 'spark', p: [0, 1.2, 0], v: [0, 0, 0.01], d: 60, m: {} })) });
  assert.equal(g.ev('foes.length'), 0, 'shells spawned far from the sender are dropped');
});

test('a cast from a player whose position we have never seen is ignored', () => {
  reset(); roster([[ME, {}], [EVIL, {}]]);
  g.message('cast', { id: EVIL, l: [{ i: 1, k: 'spark', p: [0, 1.2, 0], v: [0, 0, 0.01], d: 60, m: {} }] });
  assert.equal(g.ev('foes.length'), 0);
});

test('claimed damage is capped and a sender has a bounded damage budget', () => {
  reset(); roster([[ME, {}], [OPP, {}]]); state(OPP, 0, 0, -3);
  const burstStart = Date.now();
  for (let p = 0; p < 8; p++) g.message('cast', { id: OPP, l: Array.from({ length: 16 }, (_, i) => ({ i: p * 16 + i + 1, k: 'spark', p: [0, 1.2, -3], v: [0, 0, -0.1], d: 60, m: {} })) });
  const total = g.ev('foes.reduce((a,f)=>a+f.damage,0)');
  const largest = g.ev('Math.max(0,...foes.map(f=>f.damage))');
  assert.ok(largest <= 60, 'no single shell exceeds the hard cap');
  // The budget is a bucket of 220 that refills at 100/s of real time, so allow for the refill during this burst.
  const elapsed = (Date.now() - burstStart) / 1000;
  assert.ok(total <= 220 + 100 * elapsed + 1e-6, `128 shells were granted ${total.toFixed(1)} damage in ${elapsed.toFixed(3)}s`);
});


test('one maximum-size multicast packet cannot instantly eliminate a full-health player', () => {
  reset(); roster([[ME, {}], [OPP, {}]]); state(OPP, 0, 0, -3);
  g.message('cast', { id: OPP, l: Array.from({ length: 16 }, (_, i) => ({ i: i + 1, k: 'spark', p: [0, 1.2, -3], v: [0, 0, 0.25], d: 60, m: {} })) });
  const total = g.ev('foes.reduce((sum, projectile) => sum + projectile.damage, 0)');
  assert.ok(total <= 35 + 1e-9, `one cast packet was granted ${total} damage`);
  assert.ok(total < 100, 'one network cast packet must not be lethal to a full-health player');
});

test('an avatar cannot teleport across the map between packets', () => {
  reset(); roster([[ME, {}], [OPP, {}]]); state(OPP, 0, 0, 0);
  state(OPP, 90, 0, 90);
  const x = g.ev(`NET.st.get('${OPP}').x`);
  assert.ok(x < 30, `avatar jumped to x=${x.toFixed(1)} in one packet`);
});

test('a prep timer from another player cannot lock the room', () => {
  reset(); g.ev('NET.match.phase="lobby"'); roster([[ME, {}], [EVIL, { mode: 6, prep: Number.MAX_SAFE_INTEGER }]]);
  assert.equal(g.ev('inPrep()'), false);
  assert.ok(g.ev('NET.prepUntil') < Date.now() + 60000);
});

test('a non-host cannot end, win, or rewrite a match', () => {
  reset(); g.ev('NET.mode=1;NET.teamOverrides={}'); roster([[ME, { mode: 1 }], [OPP, { mode: 1 }]]);
  g.ev('NET.roster.forEach(r=>r.ready=true);startMatchAsHost()');
  const before = g.ev('JSON.stringify([NET.match.phase,NET.match.score])');
  g.message('match', { host: EVIL, phase: 'finished', round: 1, score: [3, 0], teams: {} });
  assert.equal(g.ev('JSON.stringify([NET.match.phase,NET.match.score])'), before);
});

test('readiness cannot be set by a broadcast that names another player', () => {
  reset(); roster([[ME, {}], [OPP, { ready: false }]]);
  g.message('ready', { id: OPP, ready: true });
  assert.equal(g.ev(`NET.roster.find(r=>r.id==='${OPP}').ready`), false);
});

test('one kill does not end a 2v2 round; the last team alive wins', () => {
  reset(); g.ev('NET.mode=2;NET.teamOverrides={}');
  roster([[ME, { mode: 2, autoTeam: true }], [ALLY, { mode: 2, autoTeam: true }], [OPP, { mode: 2, autoTeam: true }], [OPP2, { mode: 2, autoTeam: true }]]);
  g.ev('NET.roster.forEach(r=>r.ready=true);startMatchAsHost()');
  const mine = g.ev(`teamOf('${ME}')`);
  const enemies = [ALLY, OPP, OPP2].filter((id) => g.ev(`teamOf('${id}')`) !== mine);
  g.message('kill', { id: enemies[0], seq: 1, by: ME });
  assert.equal(g.ev('NET.match.phase'), 'round', 'the round continues while one enemy lives');
  g.message('kill', { id: enemies[1], seq: 2, by: ME });
  assert.notEqual(g.ev('NET.match.phase'), 'round', 'the round ends when that team has nobody left');
  assert.equal(g.ev(`NET.match.score[${mine}]`), 1);
});

test('a 1v1 elimination keeps both players in the arena intermission without disconnecting the room', () => {
  reset();
  g.ev(`NET.match={phase:'lobby',round:1,score:[0,0],credits:3,shop:{damage:1,defense:1,mana:1},hostId:null};NET.teamOverrides={};NET.on=true;NET.room='AB12-CD34';NET.roster=[]`);
  roster([[ME, { mode: 1 }], [OPP, { mode: 1 }]]);
  g.ev('NET.roster.forEach(r=>r.ready=true);startMatchAsHost()');
  const channelBefore = g.ev('NET.ch');
  g.ev(`handleKillMessage({id:'${OPP}',seq:100,by:'${ME}'})`);
  assert.equal(g.ev('NET.match.phase'), 'intermission');
  assert.equal(g.ev('NET.on'), true);
  assert.equal(g.ev('NET.inArena'), true, 'the arena remains active during intermission');
  assert.equal(g.window.document.getElementById('realmLobby').classList.contains('hidden'), true, 'the lobby stays hidden');
  assert.equal(g.window.document.getElementById('roundEnd').classList.contains('hidden'), false, 'the round-end panel is shown');
  assert.equal(g.ev("NET.room"), 'AB12-CD34');
  assert.equal(g.ev('NET.ch'), channelBefore);
  assert.match(g.window.document.getElementById('netMsg').textContent, /Still connected to room/);
});

test('a defeated player stays at zero HP throughout intermission until the next round starts', () => {
  reset();
  g.ev(`NET.match={phase:'lobby',round:1,score:[0,0],credits:3,shop:{damage:1,defense:1,mana:1},hostId:null};NET.teamOverrides={};NET.on=true;NET.room='AB12-CD34';NET.roster=[]`);
  roster([[ME, { mode: 1 }], [OPP, { mode: 1 }]]);
  g.ev('NET.roster.forEach(r=>r.ready=true);startMatchAsHost();P.hp=0;P.downT=2');
  g.ev(`applyMatchState({host:'${ME}',phase:'intermission',round:1,score:[1,0],teams:{'${ME}':0,'${OPP}':1},map:'sunken',mode:1})`);
  for (let i = 0; i < 120; i++) g.ev('upd()');
  assert.equal(g.ev('P.hp'), 0);
  assert.equal(g.ev('P.downT'), 2, 'down timer is paused between rounds');
  assert.equal(g.ev('NET.inArena'), true);
  g.ev(`applyMatchState({host:'${ME}',phase:'round',round:2,score:[1,0],teams:{'${ME}':0,'${OPP}':1},map:'sunken',mode:1})`);
  assert.equal(g.ev('P.hp'), 100, 'the next round restores full health');
  assert.equal(g.ev('P.downT'), 0);
});

test('eliminated players stay down until the next round', () => {
  reset(); g.ev('NET.mode=2;NET.teamOverrides={}');
  roster([[ME, { mode: 2, autoTeam: true }], [ALLY, { mode: 2, autoTeam: true }], [OPP, { mode: 2, autoTeam: true }], [OPP2, { mode: 2, autoTeam: true }]]);
  g.ev('NET.roster.forEach(r=>r.ready=true);startMatchAsHost();NET.prepUntil=0');
  g.ev('hurtPlayer(999,"spark")');
  for (let i = 0; i < 500; i++) g.ev('upd()');
  assert.equal(g.ev('P.hp'), 0, 'eliminated player does not respawn mid-round');
  assert.ok(g.ev('P.downT') > 0);
});

test('an opponent who leaves a duel forfeits the round after the grace period', () => {
  reset(); g.ev('NET.mode=1;NET.teamOverrides={}'); roster([[ME, { mode: 1 }], [OPP, { mode: 1 }]]);
  g.ev('NET.roster.forEach(r=>r.ready=true);startMatchAsHost()');
  roster([[ME, { mode: 1 }]]);
  g.ev('checkRoundState()');
  assert.equal(g.ev('NET.match.phase'), 'round', 'no instant forfeit: they may reconnect');
  g.ev('NET.forfeitSince=Date.now()-5000;checkRoundState()');
  assert.notEqual(g.ev('NET.match.phase'), 'round');
});

test('a round timer that runs out is decided by survivors and then health', () => {
  reset(); g.ev('NET.mode=1;NET.teamOverrides={}'); roster([[ME, { mode: 1 }], [OPP, { mode: 1 }]]);
  g.ev('NET.roster.forEach(r=>r.ready=true);startMatchAsHost();NET.prepUntil=0;NET.roundEndsAt=Date.now()-10;P.hp=90');
  state(OPP, 0, 0, -10, 40);
  g.ev('checkRoundState()');
  assert.notEqual(g.ev('NET.match.phase'), 'round');
  assert.equal(g.ev('NET.match.score[0]+NET.match.score[1]'), 1);
});

test('shop upgrades stay inside the match, and online balance sliders are locked', async () => {
  reset();
  await g.ev('netLeave(true)'); // leave the room the normal way so the saved balance is restored
  g.ev('BAL.spellDamage=1.7;BAL.defenseDuration=0.9');
  await g.ev("netJoin('AB12-CD34')"); g.ev('NET.joinT=100');
  assert.equal(g.ev('BAL.spellDamage'), g.ev('BAL_DEFAULTS.spellDamage'), 'joining a room starts from default balance');
  assert.ok([...g.window.document.querySelectorAll('#balance input')].every((el) => el.disabled), 'sliders are locked online');
  roster([[ME, { mode: 1 }], [OPP, { mode: 1 }]]);
  g.ev("NET.match.phase='intermission';NET.match.credits=6;document.getElementById('shopItem').value='damage';buyRoundUpgrade();document.getElementById('shopItem').value='mana';buyRoundUpgrade()");
  const inside = g.ev('BAL.spellDamage');
  await g.ev('netLeave(true)'); // async: wait for the restore
  assert.ok(inside > g.ev('BAL_DEFAULTS.spellDamage'), 'the upgrade applied during the match');
  assert.equal(g.ev('BAL.spellDamage'), 1.7, 'your own slider value is restored after leaving');
});

test('a legitimate remote shot still lands and applies its status effect', () => {
  reset(); roster([[ME, {}], [OPP, {}]]); state(OPP, 0, 0, -3);
  g.message('cast', { id: OPP, l: [{ i: 1, k: 'fire', p: [0, 1.2, -1.8], v: [0, 0, 0.25], d: 9, m: {} }] });
  assert.equal(g.ev('foes.length'), 1, 'the shot is created');
  for (let i = 0; i < 60; i++) g.ev('upd()');
  assert.ok(g.ev('P.hp') < 100, 'the player took damage');
  assert.ok(g.ev('P.burn') > 0, 'burning applied');
});

test('malformed packets never throw into the game loop', () => {
  reset(); roster([[ME, {}], [OPP, {}]]);
  const bad = [null, undefined, 1, 'x', [], {}, { id: OPP }, { id: '__proto__' }, { id: OPP, l: 'x' }, { id: OPP, l: [null] },
    { id: OPP, l: [{ i: 1, k: 'spark', p: null, v: null, d: 1, m: {} }] }, { id: OPP, l: [{ i: 1, k: 'constructor', p: [0, 0, 0], v: [0, 0, 0], d: 1, m: {} }] },
    { id: OPP, x: NaN, y: 0, z: 0, ry: 0, hp: 1, k: 0, dn: 0 }, { host: OPP, phase: 'finished', round: 1, score: [1, 0], forfeit: 'yes' }, { host: OPP, phase: 'finished', round: 1, score: [1, 0], winner: 7 }];
  let thrown = 0;
  for (const name of ['state', 'cast', 'hit', 'def', 'defState', 'defEnd', 'kill', 'ready', 'match']) for (const payload of bad) { try { g.message(name, payload); } catch { thrown++; } }
  assert.equal(thrown, 0);
});
