// Runs the real public/game.html game script in Node (jsdom + a fake WebGL renderer + a fake realtime channel).
// The game is a browser module, so tests reach into its scope with game.ev('<javascript>').
import { JSDOM, VirtualConsole } from 'jsdom';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const pub = path.resolve(here, '../../public');
const require = createRequire(import.meta.url);

export async function loadGame({ touch = false } = {}) {
  const html = fs.readFileSync(path.join(pub, 'game.html'), 'utf8');
  const modules = [...html.matchAll(/<script type="module">([\s\S]*?)<\/script>/g)];
  const main = modules[modules.length - 1][1].split("'./game-modules/").join(`'${pathToFileURL(pub).href}/game-modules/`);
  const body = html.replace(/<script[\s\S]*?<\/script>/g, '');

  const vc = new VirtualConsole();
  const dom = new JSDOM(body, { pretendToBeVisual: true, virtualConsole: vc, url: 'https://example.test/' });
  const w = dom.window;
  w.matchMedia = (query) => ({ matches: touch && query === '(pointer:coarse)', addListener() {}, addEventListener() {} });
  Object.defineProperty(w.navigator, 'maxTouchPoints', { value: touch ? 5 : 0, configurable: true });
  w.HTMLCanvasElement.prototype.getContext = function () {
    return new Proxy({}, { get: (t, k) => (k === 'createLinearGradient' || k === 'createRadialGradient' ? () => ({ addColorStop() {} }) : () => {}), set: () => true });
  };
  w.HTMLCanvasElement.prototype.toDataURL = () => 'data:,';
  Object.defineProperty(w.HTMLElement.prototype, 'clientWidth', { get: () => 480 });
  Object.defineProperty(w.HTMLElement.prototype, 'clientHeight', { get: () => 270 });

  const threeSource = fs.readFileSync(path.join(pub, 'vendor/three-r128.min.js'), 'utf8');
  const threeGlobal = {};
  new Function('window', 'globalThis', 'self', 'exports', 'module', 'define', threeSource)(threeGlobal, threeGlobal, threeGlobal, undefined, undefined, undefined);
  const THREE = Object.assign({}, globalThis.THREE || threeGlobal.THREE, {
    WebGLRenderer: class { constructor(o) { this.domElement = o.canvas; this.shadowMap = {}; this.domElement.height = 270; } setPixelRatio() {} setSize() {} render() {} },
  });
  w.THREE = THREE;
  for (const key of Object.getOwnPropertyNames(w)) {
    if (key in globalThis) continue;
    try { Object.defineProperty(globalThis, key, { get: () => w[key], set: (v) => { try { w[key] = v; } catch { /* read-only */ } }, configurable: true }); } catch { /* skip */ }
  }
  Object.assign(globalThis, {
    window: w, document: w.document, THREE, matchMedia: w.matchMedia, requestAnimationFrame: () => 0,
    addEventListener: w.addEventListener.bind(w), removeEventListener: w.removeEventListener.bind(w),
    localStorage: w.localStorage, location: w.location, history: w.history,
  });
  const realSetInterval = globalThis.setInterval;
  globalThis.setInterval = (fn, ms, ...args) => { const handle = realSetInterval(fn, ms, ...args); handle.unref?.(); return handle; };

  const sent = [], handlers = {};
  w.__presence = {};
  w.__sent = sent;
  const channel = () => {
    const ch = {
      on(type, filter, cb) { handlers[`${type}:${(filter && filter.event) || ''}`] = cb || filter; return ch; },
      subscribe(cb) { setTimeout(() => cb('SUBSCRIBED'), 0); return ch; },
      send(message) { sent.push(message); return Promise.resolve('ok'); },
      track() { return Promise.resolve('ok'); },
      presenceState() { return w.__presence; },
    };
    return ch;
  };
  w.SB = { channel, removeChannel: async () => {} };
  w.SB_READY = Promise.resolve(true);

  const tmp = path.join(here, `.tmp-game-${process.pid}-${Date.now()}.mjs`);
  fs.writeFileSync(tmp, `${main}\n;globalThis.__ev=(code)=>eval(code);`);
  const origWarn = console.warn;
  console.warn = (...a) => { if (!/thickness|\[net\]/.test(String(a[0]))) origWarn(...a); };
  try { await import(pathToFileURL(tmp).href); } finally { fs.rmSync(tmp, { force: true }); console.warn = origWarn; }
  globalThis.openLobby = w.openLobby;

  const game = {
    window: w, sent, handlers,
    ev: (code) => globalThis.__ev(code),
    message: (event, payload) => handlers[`broadcast:${event}`]({ payload }),
    presence(players) { w.__presence = {}; for (const [id, meta] of players) w.__presence[id] = [meta]; handlers['presence:sync'](); },
    sentOf: (event) => sent.filter((m) => m.event === event),
    dispose() { w.close(); },
  };
  return game;
}
