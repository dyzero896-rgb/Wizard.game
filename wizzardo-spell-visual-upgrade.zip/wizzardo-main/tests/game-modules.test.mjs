import test from 'node:test';
import assert from 'node:assert/strict';
import { isTouchDevice, phoneAimScore, phoneStick } from '../public/game-modules/phone-controls.js';
import { NET_LIMIT, isKnownPlayer, isRateAllowed, isValidCast, isValidState, isValidCastModifiers, copyCastModifiers, isValidStatusFlags, netNumber, netPlayerId } from '../public/game-modules/network-validation.js';
import { expectedPlayersForMode, isValidMapId, isValidRoomCode, normalizeRoomCode, MAX_ROOM_PLAYERS } from '../public/game-modules/room-rules.js';
import { SPELLS } from '../public/game-modules/spell-catalog.js';
import { DEFENSE_SPELLS } from '../public/game-modules/defense-catalog.js';
import { WAND_PRESETS } from '../public/game-modules/wand-presets.js';

test('mobile detection accounts for coarse pointers, touch points, and legacy touch support', () => {
  assert.equal(isTouchDevice({ coarsePointer: true }), true);
  assert.equal(isTouchDevice({ maxTouchPoints: 5 }), true);
  assert.equal(isTouchDevice({ ontouchstart: true }), true);
  assert.equal(isTouchDevice({ coarsePointer: false, maxTouchPoints: 0, ontouchstart: false }), false);
});

test('phone stick caps diagonal movement and preserves the dead zone', () => {
  const diagonal = phoneStick(100, -100, 46);
  assert.ok(Math.abs(Math.hypot(diagonal.mx, diagonal.my) - 1) < 1e-12);
  assert.deepEqual(phoneStick(2, 2, 46), { dx: 2, dy: 2, mx: 0, my: 0 });
  assert.equal(phoneStick(0, -46, 46).my, 1);
});

test('aim assist only scores live, visible, non-friendly targets inside the configured cone/range', () => {
  assert.ok(phoneAimScore(1, 20, true, false, true) > 0);
  assert.equal(phoneAimScore(Math.cos(Math.PI / 12), 20, true, false, true), -Infinity);
  assert.equal(phoneAimScore(1, 46, true, false, true), -Infinity);
  assert.equal(phoneAimScore(1, 20, false, false, true), -Infinity);
  assert.equal(phoneAimScore(1, 20, true, true, true), -Infinity);
  assert.equal(phoneAimScore(1, 20, true, false, false), -Infinity);
});

test('network numeric and player IDs are bounded', () => {
  assert.equal(netNumber(4, 0, 5), true);
  assert.equal(netNumber(Infinity, 0, 5), false);
  assert.equal(netNumber(6, 0, 5), false);
  assert.equal(netPlayerId('player_123'), true);
  assert.equal(netPlayerId('<bad>'), false);
  assert.equal(netPlayerId('__proto__'), false);
  assert.equal(netPlayerId('constructor'), false);
  assert.equal(netPlayerId('tiny'), false);
});

test('state packets must belong to a known player and fit documented bounds', () => {
  const roster = [{ id: 'player_123' }];
  const good = { id: 'player_123', x: 1, y: 2, z: 3, ry: 0, hp: 90, k: 0, dn: 1 };
  assert.equal(isKnownPlayer(good.id, roster), true);
  assert.equal(isValidState(good, { roster }), true);
  assert.equal(isValidState({ ...good, x: NET_LIMIT.world + 1 }, { roster }), false);
  assert.equal(isValidState({ ...good, id: 'unknown_123' }, { roster }), false);
  assert.equal(isValidState({ ...good, hp: -1 }, { roster }), false);
  assert.equal(isValidState({ ...good, st: { b: 1, p: 0, f: 1 } }, { roster }), true);
  assert.equal(isValidState({ ...good, st: { b: 2, p: 0, f: 0 } }, { roster }), false);
  assert.equal(isValidState({ ...good, st: { b: 0, p: 0, f: 0, script: true } }, { roster }), false);
  assert.equal(isValidStatusFlags({ b: 1, p: 0, f: 1 }), true);
  assert.equal(isValidStatusFlags({ b: true, p: 0, f: 1 }), false);
});

test('cast packets allow only known spell keys and bounded vectors/damage', () => {
  const roster = [{ id: 'player_123' }];
  const good = { id: 'player_123', l: [{ i: 1, k: 'spark', p: [0, 1, 0], v: [0, 0, -7], d: 3, m: { dm: 1.8, h: 1 } }] };
  assert.equal(isValidCast(good, { roster, spells: SPELLS }), true);
  assert.equal(isValidCast({ ...good, l: [{ ...good.l[0], k: 'missing' }] }, { roster, spells: SPELLS }), false);
  assert.equal(isValidCast({ ...good, l: [{ ...good.l[0], d: NET_LIMIT.castDamage + 1 }] }, { roster, spells: SPELLS }), false);
  assert.equal(isValidCast({ ...good, l: Array(17).fill(good.l[0]) }, { roster, spells: SPELLS }), false);
  assert.equal(isValidCast({ ...good, l: [{ ...good.l[0], p: [0, NaN, 0] }] }, { roster, spells: SPELLS }), false);
  assert.equal(isValidCast({ ...good, l: [{ ...good.l[0], m: { script: 'run' } }] }, { roster, spells: SPELLS }), false);
  assert.equal(isValidCast({ ...good, l: [{ ...good.l[0], m: { dm: 99 } }] }, { roster, spells: SPELLS }), false);
  assert.equal(isValidCast({ ...good, l: [{ ...good.l[0], m: { h: true } }] }, { roster, spells: SPELLS }), false);
  assert.equal(isValidCast({ ...good, l: [{ ...good.l[0], i: 0 }] }, { roster, spells: SPELLS }), false);
  assert.equal(isValidCast({ ...good, l: [good.l[0], { ...good.l[0], k: 'fire' }] }, { roster, spells: SPELLS }), false);

});

test('rate limits allow up to the configured count and reset after a window', () => {
  const bucket = Object.create(null);
  for (let i = 0; i < 2; i++) assert.equal(isRateAllowed(bucket, 'player_123', 'cast', 2, 100, 1000), true);
  assert.equal(isRateAllowed(bucket, 'player_123', 'cast', 2, 100, 1000), false);
  assert.equal(isRateAllowed(bucket, 'player_123', 'cast', 2, 1200, 1000), true);
});

test('room codes normalize to one form and invalid inputs are rejected', () => {
  assert.equal(normalizeRoomCode(' ab12cd34 '), 'AB12-CD34');
  assert.equal(normalizeRoomCode('ab12-cd34'), 'AB12-CD34');
  assert.equal(isValidRoomCode('AB12-CD34'), true);
  assert.equal(isValidRoomCode('AB12CD34'), false);
  assert.equal(normalizeRoomCode('not a code'), '');
});

test('supported team modes have correct player counts and arena IDs are allowlisted', () => {
  assert.deepEqual([1, 2, 4, 6].map(expectedPlayersForMode), [2, 4, 8, 12]);
  assert.equal(MAX_ROOM_PLAYERS, 12);
  assert.equal(expectedPlayersForMode(3), 0);
  assert.equal(isValidMapId('sunken'), true);
  assert.equal(isValidMapId('unexpected'), false);
});

test('the extracted spell catalog has not lost its key offensive and modifier entries', () => {
  for (const key of ['spark', 'fire', 'bomb', 'frost', 'orb', 'lightning', 'poison', 'void', 'gale', 'sun', 'crystal', 'water', 'earth', 'dmg', 'spd', 'bnc', 'hom', 'trl', 'big', 'dbl', 'tri', 'hit', 'tim']) {
    assert.ok(Object.hasOwn(SPELLS, key), `missing spell key: ${key}`);
  }
  assert.equal(SPELLS.spark.dmg, 3);
  assert.equal(SPELLS.fire.burn, 1);
  assert.equal(SPELLS.frost.frost, 1);
});

test('defensive spell catalog and wand presets preserve the existing entries', () => {
  for (const key of ['flame', 'glacier', 'storm', 'venom', 'bulwark', 'gale', 'tide', 'voidstep', 'radiant', 'mirror']) {
    assert.ok(Object.hasOwn(DEFENSE_SPELLS, key), `missing defense key: ${key}`);
  }
  for (const name of ['Cluster bomb', 'Homing swarm', 'Chain reaction', 'Bouncing embers', 'Ice then boom', 'Storm cascade', 'Venom cloud', 'Event Horizon', 'Solar lance', 'Tidal surge', 'Stonebreaker']) {
    assert.ok(Object.hasOwn(WAND_PRESETS, name), `missing preset: ${name}`);
  }
  assert.equal(DEFENSE_SPELLS.bulwark.c, 30);
  assert.equal(WAND_PRESETS['Cluster bomb'][0], 'hit');
});

import { DEFENSE_SYNC_LIMITS, isValidDefenseCast, isValidDefenseState, isValidDefenseEnd } from '../public/game-modules/defense-sync.js';

test('defense casts preserve geometric spell identities and require a valid bounded payload', () => {
  const roster = [{ id: 'player_123' }];
  const good = { id: 'player_123', key: 'bulwark', seq: 1, yaw: -Math.PI / 2, life: 420 };
  assert.equal(isValidDefenseCast(good, { roster, defenses: DEFENSE_SPELLS }), true);
  assert.equal(isValidDefenseCast({ ...good, key: 'absorb-all' }, { roster, defenses: DEFENSE_SPELLS }), false);
  assert.equal(isValidDefenseCast({ ...good, yaw: Infinity }, { roster, defenses: DEFENSE_SPELLS }), false);
  assert.equal(isValidDefenseCast({ ...good, life: DEFENSE_SYNC_LIMITS.maxLifeFrames + 1 }, { roster, defenses: DEFENSE_SPELLS }), false);
  assert.equal(isValidDefenseCast({ ...good, seq: 0 }, { roster, defenses: DEFENSE_SPELLS }), false);
});

test('defense lifetime updates and end events must belong to a known player and valid sequence', () => {
  const roster = [{ id: 'player_123' }];
  assert.equal(isValidDefenseState({ id: 'player_123', seq: 2, life: 120 }, { roster }), true);
  assert.equal(isValidDefenseState({ id: 'player_123', seq: 2, life: -1 }, { roster }), false);
  assert.equal(isValidDefenseState({ id: 'unknown_123', seq: 2, life: 0 }, { roster }), false);
  assert.equal(isValidDefenseEnd({ id: 'player_123', seq: 2 }, { roster }), true);
  assert.equal(isValidDefenseEnd({ id: 'player_123', seq: -2 }, { roster }), false);
});

test('cast modifiers are a small allowlisted data object with bounded values', () => {
  assert.equal(isValidCastModifiers({}), true);
  assert.equal(isValidCastModifiers({ dm: 1.8, sm: 1.7, bl: 2, b: 3, h: 1, tr: 1 }), true);
  assert.equal(isValidCastModifiers({ dm: 0.5 }), false);
  assert.equal(isValidCastModifiers({ b: 7 }), false);
  assert.equal(isValidCastModifiers({ h: 0 }), false);
  assert.equal(isValidCastModifiers({ onHit: 'explode' }), false);
  assert.equal(isValidCastModifiers(null), false);
  assert.deepEqual(copyCastModifiers({ dm: 1.8, h: 1 }), { dm: 1.8, h: 1 });
  assert.equal(copyCastModifiers({ arbitrary: true }), null);
});

import { selectHomingTarget, steerHomingVelocity } from '../public/game-modules/homing.js';

test('homing target selection ignores the owner, teammates, dead and invisible players', () => {
  const candidates = [
    { id: 'caster_123', position: [0, 0, 0], alive: true, visible: true, team: 0 },
    { id: 'ally__123', position: [1, 0, 0], alive: true, visible: true, team: 0 },
    { id: 'dead__123', position: [2, 0, 0], alive: false, visible: true, team: 1 },
    { id: 'hidden_123', position: [3, 0, 0], alive: true, visible: false, team: 1 },
    { id: 'enemy_123', position: [8, 0, 0], alive: true, visible: true, team: 1 },
    { id: 'enemy_456', position: [5, 0, 0], alive: true, visible: true, team: 1 },
  ];
  const selected = selectHomingTarget([0, 0, 0], candidates, {
    ownerId: 'caster_123', ownerTeam: 0, teamsEnabled: true,
  });
  assert.deepEqual(selected, { id: 'enemy_456', position: [5, 0, 0] });
});

test('homing selects any opponent in free-for-all and locks a still-valid preferred target', () => {
  const candidates = [
    { id: 'enemy__123', position: [12, 0, 0], alive: true, visible: true, team: 0 },
    { id: 'enemy__456', position: [4, 0, 0], alive: true, visible: true, team: 0 },
  ];
  assert.equal(selectHomingTarget([0, 0, 0], candidates, { ownerId: 'caster_123' }).id, 'enemy__456');
  assert.equal(selectHomingTarget([0, 0, 0], candidates, { ownerId: 'caster_123', preferredId: 'enemy__123' }).id, 'enemy__123');
  assert.equal(selectHomingTarget([0, 0, 0], candidates, { ownerId: 'caster_123', teamsEnabled: true, ownerTeam: 0 }), null);
});

test('homing rejects malformed or out-of-range targets', () => {
  assert.equal(selectHomingTarget([0, 0, 0], [{ id: 'bad', position: [NaN, 0, 0], alive: true }]), null);
  assert.equal(selectHomingTarget([0, 0, 0], [{ id: 'far__123', position: [131, 0, 0], alive: true }]), null);
  assert.equal(selectHomingTarget([0, 0], [], {}), null);
});

test('homing steering turns toward the target while preserving projectile speed', () => {
  const result = steerHomingVelocity([0, 0, -10], [0, 0, 0], [10, 0, 0], 0.12);
  assert.ok(result[0] > 0, 'projectile should begin turning toward positive X');
  assert.ok(result[2] < 0, 'projectile should preserve forward momentum while turning');
  assert.ok(Math.abs(Math.hypot(...result) - 10) < 1e-10, 'speed should stay constant');
  assert.deepEqual(steerHomingVelocity([0, 0, 0], [0, 0, 0], [1, 0, 0]), [0, 0, 0]);
});


import { isValidCombatHit } from '../public/game-modules/combat-network.js';

test('hit confirmations require known opposing players, a known projectile, spell, bounded damage and position', () => {
  const roster = [{ id: 'player_123' }, { id: 'opponent_456' }];
  const good = { from: 'opponent_456', to: 'player_123', i: 42, d: 12.5, k: 'fire', p: [2, 1.5, -3] };
  assert.equal(isValidCombatHit(good, { roster, spells: SPELLS }), true);
  assert.equal(isValidCombatHit({ ...good, from: 'unknown_123' }, { roster, spells: SPELLS }), false);
  assert.equal(isValidCombatHit({ ...good, to: 'opponent_456' }, { roster, spells: SPELLS }), false);
  assert.equal(isValidCombatHit({ ...good, i: 0 }, { roster, spells: SPELLS }), false);
  assert.equal(isValidCombatHit({ ...good, d: 61 }, { roster, spells: SPELLS }), false);
  assert.equal(isValidCombatHit({ ...good, k: 'missing' }, { roster, spells: SPELLS }), false);
  assert.equal(isValidCombatHit({ ...good, p: [0, Infinity, 0] }, { roster, spells: SPELLS }), false);
  assert.equal(isValidCombatHit({ ...good, script: 'run' }, { roster, spells: SPELLS }), false);
});


import { statusTickDamage, statusSource, isLethalTransition } from '../public/game-modules/status-combat.js';

test('burn and poison damage ticks use bounded, deterministic 30-frame intervals', () => {
  assert.equal(statusTickDamage('burn', 150), 1.5);
  assert.equal(statusTickDamage('burn', 149), 0);
  assert.equal(statusTickDamage('poison', 120), 1);
  assert.equal(statusTickDamage('poison', 119), 0);
  assert.equal(statusTickDamage('unknown', 120), 0);
  assert.equal(statusTickDamage('burn', 0), 0);
  assert.equal(statusTickDamage('burn', 1.5), 0);
});

test('status tick kill credit follows the matching status source, not another effect', () => {
  const sources = { burn: 'attacker_123', poison: 'attacker_456' };
  assert.equal(statusSource('burn', sources), 'attacker_123');
  assert.equal(statusSource('poison', sources), 'attacker_456');
  assert.equal(statusSource('freeze', sources), null);
  assert.equal(statusSource('burn', { burn: null }), null);
  assert.equal(statusSource('poison', { poison: 'tiny' }), null);
});

test('only the first positive-to-zero health transition emits a death event', () => {
  assert.equal(isLethalTransition(1, 0), true);
  assert.equal(isLethalTransition(4, -1), true);
  assert.equal(isLethalTransition(0, 0), false);
  assert.equal(isLethalTransition(0, -1), false);
  assert.equal(isLethalTransition(5, 2), false);
  assert.equal(isLethalTransition(NaN, 0), false);
});

import { buildTeamAssignments, hasBothTeams, isValidTeamAssignments, calculateTeamScore } from '../public/game-modules/match-rules.js';

test('1v1 always assigns the two players to opposing teams, regardless of stale lobby choices', () => {
  const roster = [{ id: 'player_123', team: 0 }, { id: 'opponent_456', team: 0 }];
  const teams = buildTeamAssignments(roster, 1);
  assert.deepEqual({ ...teams }, { player_123: 0, opponent_456: 1 });
  assert.equal(hasBothTeams(teams, roster), true);
});

test('a manual Moon choice by the first duelist is preserved and the opponent is assigned Sun', () => {
  const roster = [{ id: 'player_123', team: 1, autoTeam: false }, { id: 'opponent_456', team: 1, autoTeam: false }];
  assert.deepEqual({ ...buildTeamAssignments(roster, 1) }, { player_123: 1, opponent_456: 0 });
});

test('auto-balanced teams distribute players across the smaller team while manual team choices are respected', () => {
  const roster = [
    { id: 'player_123', team: 0, autoTeam: true },
    { id: 'opponent_456', team: 0, autoTeam: true },
    { id: 'player__789', team: 1, autoTeam: false },
    { id: 'opponent_abc', team: 0, autoTeam: true },
  ];
  const teams = buildTeamAssignments(roster, 2);
  assert.deepEqual({ ...teams }, { player_123: 0, opponent_456: 1, player__789: 1, opponent_abc: 0 });
  assert.equal(hasBothTeams(teams, roster), true);
  assert.equal(isValidTeamAssignments(teams, roster), true);
  assert.equal(isValidTeamAssignments({ player_123: 0 }, roster), false);
  assert.equal(isValidTeamAssignments({ ...teams, unknown__1: 1 }, roster), false);
});

test('team scoring increments only a valid team and declares a winner at the target score', () => {
  assert.deepEqual(calculateTeamScore([1, 2], 0, 3), { score: [2, 2], finished: false, scoringTeam: 0 });
  assert.deepEqual(calculateTeamScore([2, 2], 1, 3), { score: [2, 3], finished: true, scoringTeam: 1 });
  assert.equal(calculateTeamScore([0, 0], 2, 3), null);
  assert.equal(calculateTeamScore([0], 0, 3), null);
});

import { sanitizeDisplayName, formatInviteCode } from '../public/game-modules/lobby-flow.js';
import { readFileSync } from 'node:fs';

test('guest/profile names are sanitized, bounded and fall back safely', () => {
  assert.equal(sanitizeDisplayName('  Ari Mage  '), 'Ari Mage');
  assert.equal(sanitizeDisplayName('<img>\u0000Ari'), 'imgAri');
  assert.equal(sanitizeDisplayName('x'.repeat(40)).length, 20);
  assert.equal(sanitizeDisplayName('  '), 'Guest Mage');
});

test('formatted room invites match the accepted room-code format', () => {
  const code = formatInviteCode(Uint8Array.from([0, 1, 2, 3, 250, 251, 252, 253]));
  assert.match(code, /^[A-Z2-9]{4}-[A-Z2-9]{4}$/);
  assert.equal(isValidRoomCode(code), true);
  assert.equal(formatInviteCode([1, 2]), '');
  assert.equal(formatInviteCode([1, 2, 3, 4, 5, 6, 7, NaN]), '');
});

test('lobby has only one primary click handler for room join and leave', () => {
  const html = readFileSync(new URL('../public/game.html', import.meta.url), 'utf8');
  assert.equal((html.match(/\$l\('joinRoomBtn'\)\.addEventListener\('click'/g) || []).length, 1);
  assert.equal((html.match(/\$l\('leaveRoomBtn'\)\.addEventListener\('click'/g) || []).length, 1);
  assert.match(html, /Room connected and ready/);
  assert.match(html, /Room was not created/);
});
