import test from 'node:test';
import assert from 'node:assert/strict';
import {
  CAST_ORIGIN_MAX_DISTANCE, CAST_PACKET_DAMAGE_MAX, DAMAGE_BUDGET, PREP_MAX_LEAD_MS, STATE_MAX_SPEED,
  balanceForShop, clampClaimedDamage, scaleCastPacketDamage, decideRoundWinner, forfeitWinner, isNearSender,
  limitStateStep, maxClaimedDamage, roundOutcome, sanitizePrepDeadline, spendDamageBudget, teamsAlive,
} from '../public/game-modules/hardening.js';

test('claimed damage is capped by the spell table, not by the packet', () => {
  assert.ok(clampClaimedDamage(60, { dmg: 3 }, {}) < 40, 'a spark cannot claim 60 damage');
  assert.equal(clampClaimedDamage(5, { dmg: 3 }, {}), 5);
  assert.equal(clampClaimedDamage(-4, { dmg: 3 }, {}), 0);
  assert.equal(clampClaimedDamage(Number.NaN, { dmg: 3 }, {}), 0);
  assert.equal(clampClaimedDamage(Infinity, { dmg: 3 }, {}) <= 60, true);
  assert.ok(maxClaimedDamage({ dmg: 30 }, { dm: 1.8 }) <= 60);
  assert.ok(maxClaimedDamage({ dmg: 3 }, { dm: 3 }) > maxClaimedDamage({ dmg: 3 }, {}));
  assert.ok(maxClaimedDamage(undefined, undefined) >= 1);
});

test('one cast packet is scaled so its combined damage cannot be lethal', () => {
  const cast = { l: Array.from({ length: 16 }, (_, i) => ({ i: i + 1, k: 'spark', d: 60, m: {} })) };
  const damage = scaleCastPacketDamage(cast, { spark: { dmg: 3 } });
  assert.equal(damage.length, 16);
  assert.ok(damage.reduce((sum, value) => sum + value, 0) <= CAST_PACKET_DAMAGE_MAX + 1e-9);
  assert.ok(damage.every((value) => value >= 0));
  assert.ok(damage.every((value) => Math.abs(value - CAST_PACKET_DAMAGE_MAX / 16) < 1e-9));
  assert.deepEqual(scaleCastPacketDamage({ l: [{ k: 'spark', d: 5, m: {} }] }, { spark: { dmg: 3 } }), [5]);
  assert.deepEqual(scaleCastPacketDamage(null, { spark: { dmg: 3 } }), []);
});

test('a cast has to start near the sender', () => {
  const sender = { x: 10, y: 0, z: -4 };
  assert.equal(isNearSender([10, 1.2, -5], sender), true);
  assert.equal(isNearSender([10 + CAST_ORIGIN_MAX_DISTANCE + 1, 0, -4], sender), false);
  assert.equal(isNearSender([0, 0, 0], null), false);
  assert.equal(isNearSender([0, 0], sender), false);
  assert.equal(isNearSender([0, Number.NaN, 0], sender), false);
});

test('avatars cannot teleport, but respawns and deaths may move them', () => {
  const prev = { x: 0, y: 0, z: 0, hp: 100, dn: 0 };
  const far = limitStateStep(prev, { x: 100, y: 0, z: 0, hp: 100, dn: 0 }, 100);
  assert.ok(far.x > 0 && far.x <= STATE_MAX_SPEED * 0.1 + 4 + 1e-9);
  assert.deepEqual(limitStateStep(prev, { x: 3, y: 0, z: 0, hp: 100, dn: 0 }, 100).x, 3);
  assert.equal(limitStateStep(prev, { x: 90, y: 0, z: 0, hp: 100, dn: 1 }, 100).x, 90, 'new death count = respawn');
  assert.equal(limitStateStep({ ...prev, hp: 0 }, { x: 90, y: 0, z: 0, hp: 100, dn: 0 }, 100).x, 90, 'was downed');
  assert.equal(limitStateStep(null, { x: 90, y: 0, z: 0, hp: 100, dn: 0 }, 100).x, 90);
});

test('the damage budget refills over time and cannot be exceeded in one burst', () => {
  const buckets = {};
  let granted = 0;
  for (let i = 0; i < 128; i++) granted += spendDamageBudget(buckets, 'a', 34, 1000);
  assert.ok(granted <= DAMAGE_BUDGET.capacity + 1e-9);
  assert.equal(spendDamageBudget(buckets, 'a', 10, 1000), 0);
  assert.ok(spendDamageBudget(buckets, 'a', 1000, 2000) <= DAMAGE_BUDGET.refillPerSecond + 1e-9);
  assert.ok(spendDamageBudget(buckets, 'b', 10, 1000) > 0, 'budgets are per sender');
  assert.equal(spendDamageBudget(buckets, 'a', -5, 5000), 0);
  assert.equal(spendDamageBudget(buckets, 'a', Number.NaN, 5000), 0);
});

test('prep deadlines from other players must be in the near future', () => {
  const now = 1_000_000;
  assert.equal(sanitizePrepDeadline(now + 5000, now), now + 5000);
  assert.equal(sanitizePrepDeadline(now + PREP_MAX_LEAD_MS + 1, now), 0);
  assert.equal(sanitizePrepDeadline(Number.MAX_SAFE_INTEGER, now), 0);
  assert.equal(sanitizePrepDeadline(now - 60_000, now), 0);
  assert.equal(sanitizePrepDeadline('soon', now), 0);
  assert.equal(sanitizePrepDeadline(Number.NaN, now), 0);
});

test('a round ends when one team has nobody left (last team standing)', () => {
  const team = (id) => (id.startsWith('a') ? 0 : id.startsWith('b') ? 1 : null);
  const roster = [{ id: 'a1' }, { id: 'a2' }, { id: 'b1' }, { id: 'b2' }];
  assert.deepEqual(teamsAlive(roster, new Set(), team), [2, 2]);
  assert.deepEqual(teamsAlive(roster, new Set(['b1']), team), [2, 1]);
  assert.deepEqual(roundOutcome([2, 1]), { over: false, winner: null });
  assert.deepEqual(roundOutcome([2, 0]), { over: true, winner: 0 });
  assert.deepEqual(roundOutcome([0, 1]), { over: true, winner: 1 });
  assert.deepEqual(roundOutcome([0, 0]), { over: true, winner: null });
  assert.deepEqual(teamsAlive([{ id: 'zz' }], new Set(), team), [0, 0]);
});

test('timeouts are decided by survivors, then total health, otherwise a draw', () => {
  assert.equal(decideRoundWinner([2, 1], [10, 300]), 0);
  assert.equal(decideRoundWinner([1, 2], [300, 10]), 1);
  assert.equal(decideRoundWinner([1, 1], [80, 40]), 0);
  assert.equal(decideRoundWinner([1, 1], [40, 80]), 1);
  assert.equal(decideRoundWinner([1, 1], [50, 50]), null);
});

test('a team that left the room forfeits', () => {
  const team = (id) => (id.startsWith('a') ? 0 : id.startsWith('b') ? 1 : null);
  assert.equal(forfeitWinner([{ id: 'a1' }, { id: 'b1' }], team), null);
  assert.equal(forfeitWinner([{ id: 'a1' }], team), 0);
  assert.equal(forfeitWinner([{ id: 'b1' }, { id: 'b2' }], team), 1);
  assert.equal(forfeitWinner([], team), null);
});

test('shop upgrades are derived from defaults, so they cannot pile up between matches', () => {
  const defaults = { spellDamage: 0.9, defenseDuration: 0.7 };
  assert.deepEqual(balanceForShop(defaults, { damage: 1, defense: 1, mana: 1 }), { spellDamage: 0.9, defenseDuration: 0.7, manaMultiplier: 1 });
  const b = balanceForShop(defaults, { damage: 1.2, defense: 1.1, mana: 1.1 });
  assert.ok(Math.abs(b.spellDamage - 1.1) < 1e-12 && Math.abs(b.defenseDuration - 0.8) < 1e-12 && Math.abs(b.manaMultiplier - 1.2) < 1e-12);
  assert.ok(balanceForShop(defaults, { damage: 9, defense: 9, mana: 9 }).spellDamage <= 2);
  assert.equal(balanceForShop(defaults, undefined).manaMultiplier, 1);
});
