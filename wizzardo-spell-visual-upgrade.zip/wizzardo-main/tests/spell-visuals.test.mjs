import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { SPELLS } from '../public/game-modules/spell-catalog.js';
import { SPELL_VISUALS, PROJECTILE_VISUAL_KEYS, hasCompleteProjectileVisuals } from '../public/game-modules/spell-visual-catalog.js';

const projectileKeys = Object.keys(SPELLS).filter((key) => SPELLS[key].t === 'p');

test('every projectile spell has its own complete visual identity', () => {
  assert.equal(hasCompleteProjectileVisuals(SPELLS), true);
  assert.deepEqual([...PROJECTILE_VISUAL_KEYS].sort(), [...projectileKeys].sort());
  for (const key of projectileKeys) {
    const visual = SPELL_VISUALS[key];
    assert.match(visual.primary, /^#[0-9a-f]{6}$/i, `${key} primary colour`);
    assert.match(visual.accent, /^#[0-9a-f]{6}$/i, `${key} accent colour`);
    assert.ok(visual.silhouette && visual.trail && visual.impact, `${key} visual signature`);
  }
});

test('spell visual signatures are not just colour swaps', () => {
  for (const field of ['silhouette', 'trail', 'impact']) {
    const unique = new Set(PROJECTILE_VISUAL_KEYS.map((key) => SPELL_VISUALS[key][field]));
    assert.equal(unique.size, PROJECTILE_VISUAL_KEYS.length, `${field} should be unique per projectile spell`);
  }
});

test('visual catalog contains no gameplay tuning fields', () => {
  for (const visual of Object.values(SPELL_VISUALS)) {
    for (const forbidden of ['damage', 'dmg', 'speed', 'sp', 'radius', 'r', 'life', 'cost', 'c', 'gravity', 'g', 'cooldown']) {
      assert.equal(Object.hasOwn(visual, forbidden), false, `visual catalog must not define ${forbidden}`);
    }
  }
});

test('the 13 spell-specific models, trails and impact effects are connected to local and room projectiles', () => {
  const html = readFileSync(new URL('../public/game.html', import.meta.url), 'utf8');
  assert.match(html, /import \{ SPELL_VISUALS \} from '\.\/game-modules\/spell-visual-catalog\.js'/);
  assert.match(html, /function mkProj\(s,m\)/);
  assert.match(html, /function fxTrail\(p\)/);
  assert.match(html, /function fxSpellImpact\(p\)/);
  for (const key of projectileKeys) assert.match(html, new RegExp(`s===S\\.${key}`), `${key} model branch`);
  assert.match(html, /fxTrail\(f\)/, 'incoming room projectiles use spell-specific trails');
  assert.match(html, /else fxSpellImpact\(f\)/, 'incoming room projectiles use spell-specific direct-hit effects');
});
